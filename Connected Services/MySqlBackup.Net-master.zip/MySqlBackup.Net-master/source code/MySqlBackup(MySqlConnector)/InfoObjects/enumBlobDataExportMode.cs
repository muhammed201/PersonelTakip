﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MySqlConnector
{
    public enum BlobDataExportMode
    {
        HexString = 1,
        BinaryChar = 2
    }
}
