-- --------------------------------------------------------
-- Sunucu:                       127.0.0.1
-- Sunucu sürümü:                8.0.29 - MySQL Community Server - GPL
-- Sunucu İşletim Sistemi:       Win64
-- HeidiSQL Sürüm:               12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- bilgiislem için veritabanı yapısı dökülüyor
CREATE DATABASE IF NOT EXISTS `bilgiislem` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bilgiislem`;

-- tablo yapısı dökülüyor bilgiislem.courts
CREATE TABLE IF NOT EXISTS `courts` (
  `idcourts` int NOT NULL,
  `court` varchar(45) NOT NULL,
  `roomnumber` varchar(15) DEFAULT NULL,
  `floor` varchar(15) DEFAULT NULL,
  `build` varchar(20) DEFAULT NULL,
  `note` tinytext,
  `courtlog` tinytext,
  PRIMARY KEY (`idcourts`,`court`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- bilgiislem.courts: ~7 rows (yaklaşık) tablosu için veriler indiriliyor
REPLACE INTO `courts` (`idcourts`, `court`, `roomnumber`, `floor`, `build`, `note`, `courtlog`) VALUES
	(0, 'Komisyon', '321', '3', 'Ana Bina', 'Komisyon Sekreteri Yanı', NULL),
	(1, 'Bilgi İşlem Teknik', '241', '2', 'Ana Bina', '1. Asliye Hukuk Arkası(Teknik)', NULL),
	(2, 'Bilgi İşlem Uyap', '258', '2', 'Ana Bina', 'Uyapcılar', NULL),
	(3, '1. İş Mahkemesi', '265-235-248', '2', 'AAna Bina', NULL, NULL),
	(4, '2. Aile Mahkemesi', '101', NULL, NULL, NULL, NULL),
	(5, '1. İş Mahkemesi', '269', NULL, NULL, NULL, NULL),
	(6, '1. Aile Mahkemesi ', '107', NULL, NULL, NULL, NULL);

-- tablo yapısı dökülüyor bilgiislem.duties
CREATE TABLE IF NOT EXISTS `duties` (
  `idduties` int NOT NULL,
  `duty` varchar(30) NOT NULL,
  PRIMARY KEY (`idduties`,`duty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- bilgiislem.duties: ~9 rows (yaklaşık) tablosu için veriler indiriliyor
REPLACE INTO `duties` (`idduties`, `duty`) VALUES
	(0, 'Tekniker'),
	(1, 'Teknisyen'),
	(2, 'Hakim'),
	(3, 'Savcı'),
	(4, 'Zabıt Katibi'),
	(5, 'Mübaşir'),
	(6, 'Odacı'),
	(7, 'Yazı İşleri Müdürü'),
	(8, 'Hizmetli');

-- tablo yapısı dökülüyor bilgiislem.mahkeme
CREATE TABLE IF NOT EXISTS `mahkeme` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mahkemeler` varchar(50) NOT NULL,
  PRIMARY KEY (`id`,`mahkemeler`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- bilgiislem.mahkeme: ~10 rows (yaklaşık) tablosu için veriler indiriliyor
REPLACE INTO `mahkeme` (`id`, `mahkemeler`) VALUES
	(1, '1. Asliye Hukuk Mahkemesi'),
	(2, '2. Asliye Hukuk Mahkemesi'),
	(3, '3. Asliye Hukuk Mahkemesi'),
	(4, '4. Asliye Hukuk Mahkemesi'),
	(5, '5. Asliye Hukuk Mahkemesi'),
	(6, '1. Aile Mahkemesi'),
	(7, '2. Aile Mahkemesi'),
	(8, '3. Aile Mahkemesi'),
	(9, '4. Aile Mahkemesi'),
	(10, '5. Aile Mahkemesi');

-- tablo yapısı dökülüyor bilgiislem.sarf
CREATE TABLE IF NOT EXISTS `sarf` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sarfMalzeme` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- bilgiislem.sarf: ~2 rows (yaklaşık) tablosu için veriler indiriliyor
REPLACE INTO `sarf` (`id`, `sarfMalzeme`) VALUES
	(1, 'Toner'),
	(2, 'Dram'),
	(3, 'CD');

-- tablo yapısı dökülüyor bilgiislem.staff
CREATE TABLE IF NOT EXISTS `staff` (
  `idstaff` int NOT NULL AUTO_INCREMENT,
  `registration` varchar(10) NOT NULL,
  `stafName` varchar(45) DEFAULT NULL,
  `stafSurname` varchar(45) DEFAULT NULL,
  `duty` int DEFAULT NULL,
  `department` int DEFAULT NULL,
  `mobilephone` varchar(12) DEFAULT NULL,
  `internalphone` varchar(10) DEFAULT NULL,
  `reg` varchar(10) DEFAULT NULL,
  `regdate` datetime DEFAULT NULL,
  `stafflog` mediumtext,
  PRIMARY KEY (`idstaff`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- bilgiislem.staff: ~15 rows (yaklaşık) tablosu için veriler indiriliyor
REPLACE INTO `staff` (`idstaff`, `registration`, `stafName`, `stafSurname`, `duty`, `department`, `mobilephone`, `internalphone`, `reg`, `regdate`, `stafflog`) VALUES
	(17, 'ab126348', 'Muhammed', 'Zengin', 0, 1, '533 510 4921', '4444', 'uuu', '2022-09-14 01:35:57', 'uuu tarihinde kayıt edildi'),
	(22, 'ab145854', 'Erkan', 'Coşu', 0, 1, '533 510 4921', '4444', 'uuu', '2022-09-17 01:38:16', 'uuu tarihinde kayıt edildi'),
	(23, 'ab180883', 'Serhat', 'Keleş', 0, 1, '564 545 6465', '5646', 'uuu', '2022-09-17 01:38:34', 'uuu tarihinde kayıt edildi'),
	(24, 'ab114525', 'Yasin', 'Geren', 0, 1, '564 546 5456', '5665', 'uuu', '2022-09-17 01:38:56', 'uuu tarihinde kayıt edildi'),
	(30, 'ab126346', 'Deneme', 'deneme', 5, 5, '533 512 5485', '5555', 'uuu', '2022-09-19 22:44:02', '2022-09-19-22:44:02 tarihinde kayıt edildi'),
	(31, 'ab45852', 'Hacı', 'Veli', 3, 5, '555 541 4954', '5588', 'uuu', '2022-09-20 23:52:48', '2022-09-20-23:52:48 tarihinde kayıt edildi'),
	(32, 'ab854444', 'Ayşe', 'Fatma', 3, 6, '533 585 4555', '5454', 'uuu', '2022-09-20 23:53:18', '2022-09-20-23:53:18 tarihinde kayıt edildi'),
	(33, 'ab564564', 'Ahmet', 'Hasan', 2, 5, '533 585 4555', '54564', 'uuu', '2022-09-20 23:53:36', '2022-09-20-23:53:36 tarihinde kayıt edildi'),
	(34, 'ab54564', 'Elif', 'Yılmaz', 2, 5, '533 585 4555', '51441', 'uuu', '2022-09-20 23:53:55', '2022-09-20-23:53:55 tarihinde kayıt edildi'),
	(35, 'ab484545', 'Adnan', 'Yılmaz', 6, 1, '533 585 4555', '533 585 45', 'uuu', '2022-09-20 23:54:12', '2022-09-20-23:54:12 tarihinde kayıt edildi'),
	(36, 'ab58556', 'Yağmur', 'Can', 7, 5, '533 585 4555', '54654', 'uuu', '2022-09-20 23:55:30', '2022-09-20-23:55:30 tarihinde kayıt edildi'),
	(37, 'ab54567', 'Azra', 'Coşu', 7, 1, '533 585 4555', '54965', 'uuu', '2022-09-20 23:55:56', '2022-09-20-23:55:56 tarihinde kayıt edildi'),
	(38, 'ab125225', 'Ahmet Ediz', 'Zengin', 7, 1, '533 585 4555', '54156', 'uuu', '2022-09-20 23:56:22', '2022-09-20-23:56:22 tarihinde kayıt edildi'),
	(39, 'ab752145', 'Hakkı', 'Ali', 4, 4, '533 585 4555', '56485', 'uuu', '2022-09-20 23:56:51', '2022-09-20-23:56:51 tarihinde kayıt edildi'),
	(40, 'ab95856', 'Hakan', 'Üretme', 5, 2, '533 585 4555', '458748', 'uuu', '2022-09-20 23:57:21', '2022-09-20-23:57:21 tarihinde kayıt edildi'),
	(41, 'ab458562', 'Seyit', 'Fethi', 1, 4, '533 510 4265', '65454', 'ab126348', '2022-09-21 00:56:51', '2022-09-21-00:56:51 tarihinde kayıt edildi');

-- tablo yapısı dökülüyor bilgiislem.stok
CREATE TABLE IF NOT EXISTS `stok` (
  `id` int NOT NULL AUTO_INCREMENT,
  `urun` varchar(50) NOT NULL,
  `sarf` varchar(20) NOT NULL,
  `adet` int NOT NULL,
  `kritikStok` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- bilgiislem.stok: ~7 rows (yaklaşık) tablosu için veriler indiriliyor
REPLACE INTO `stok` (`id`, `urun`, `sarf`, `adet`, `kritikStok`) VALUES
	(1, 'Lexmark 811', 'Toner', 20, 5),
	(2, 'Lexmark 811', 'Dram', 10, 4),
	(3, 'Canon 6670', 'Toner', 10, 3),
	(4, 'Oki', 'Toner', 5, 5),
	(5, 'CD/DVD', 'CD', 31, 5),
	(6, 'Hp 1018', 'CD', 15, 0),
	(7, 'Canon 6670', 'CD', 3, 5);

-- tablo yapısı dökülüyor bilgiislem.test
CREATE TABLE IF NOT EXISTS `test` (
  `id` int NOT NULL AUTO_INCREMENT,
  `baglanti` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- bilgiislem.test: ~0 rows (yaklaşık) tablosu için veriler indiriliyor
REPLACE INTO `test` (`id`, `baglanti`) VALUES
	(1, 'OK');

-- tablo yapısı dökülüyor bilgiislem.urun
CREATE TABLE IF NOT EXISTS `urun` (
  `id` int NOT NULL AUTO_INCREMENT,
  `markaModel` varchar(50) NOT NULL,
  PRIMARY KEY (`id`,`markaModel`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- bilgiislem.urun: ~6 rows (yaklaşık) tablosu için veriler indiriliyor
REPLACE INTO `urun` (`id`, `markaModel`) VALUES
	(1, 'Lexmark 811'),
	(2, 'Lexmark 823'),
	(3, 'Oki'),
	(4, 'Canon 6670'),
	(5, 'Hp 1018'),
	(6, 'CD/DVD');

-- tablo yapısı dökülüyor bilgiislem.users
CREATE TABLE IF NOT EXISTS `users` (
  `idusers` int NOT NULL AUTO_INCREMENT,
  `userName` varchar(10) DEFAULT NULL,
  `userPassword` varchar(10) DEFAULT NULL,
  `userAuthority` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`idusers`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- bilgiislem.users: ~2 rows (yaklaşık) tablosu için veriler indiriliyor
REPLACE INTO `users` (`idusers`, `userName`, `userPassword`, `userAuthority`) VALUES
	(1, 'ab126348', '42', 'admin'),
	(2, 'ab111111', '26', 'user'),
	(3, 'a', 'a', 'user');

-- tablo yapısı dökülüyor bilgiislem.verilenler
CREATE TABLE IF NOT EXISTS `verilenler` (
  `id` int NOT NULL AUTO_INCREMENT,
  `urun` varchar(50) NOT NULL,
  `sarf` varchar(50) NOT NULL,
  `adet` int NOT NULL,
  `alanBrim` varchar(50) NOT NULL,
  `teslimAlan` varchar(50) NOT NULL,
  `teslimTarihi` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- bilgiislem.verilenler: ~2 rows (yaklaşık) tablosu için veriler indiriliyor
REPLACE INTO `verilenler` (`id`, `urun`, `sarf`, `adet`, `alanBrim`, `teslimAlan`, `teslimTarihi`) VALUES
	(10, 'CD/DVD', 'CD', 1, '1. Aile Mahkemesi', '126348', '2022-05-29');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
